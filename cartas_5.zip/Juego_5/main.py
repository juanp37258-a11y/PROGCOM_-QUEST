# main.py
# Punto de entrada del programa.
# Permite jugar una partida y, al terminar, ofrece reiniciar o salir.

from juego import Juego


def main():
    """
    Función principal.
    Crea una instancia de Juego, la inicia y, al terminar,
    pregunta al jugador si desea jugar de nuevo.
    """
    while True:
        # Cada partida crea un Juego nuevo con estado limpio
        partida = Juego()
        partida.iniciar()

        print()
        respuesta = input("  Deseas jugar de nuevo? (s/n): ").strip().lower()

        if respuesta != "s":
            print("\n  Gracias por jugar Arena de Heroes. Hasta la proxima!\n")
            break


if __name__ == "__main__":
    main()
