# accion.py
# Define la clase Accion: representa una habilidad usable en combate.
# Es responsable de su propio nombre, efecto, tipo y usos restantes.


class Accion:
    """
    Representa una acción de combate disponible para el héroe.

    Atributos:
        nombre         (str)   : Nombre visible de la acción.
        descripcion    (str)   : Texto corto que describe el efecto.
        usos_max       (int)   : Usos totales al inicio de la partida.
        usos_restantes (int)   : Usos que quedan disponibles.
        tipo           (str)   : Categoría de la acción (ver TIPOS_VALIDOS).
        valor          (float) : Daño, HP curado o factor según el tipo.
    """

    # Tipos de acción permitidos en el juego
    TIPOS_VALIDOS = {"ataque_basico", "ataque_fuerte", "curacion", "defensa"}

    def __init__(self, nombre: str, descripcion: str, usos_max: int, tipo: str, valor: float):
        """
        Inicializa una acción de combate.

        Args:
            nombre:      Nombre de la acción mostrado al jugador.
            descripcion: Descripción breve del efecto.
            usos_max:    Cantidad máxima de usos en la partida.
            tipo:        Tipo de acción (debe estar en TIPOS_VALIDOS).
            valor:       Magnitud del efecto (daño, curación o factor de reducción).
        """
        if tipo not in self.TIPOS_VALIDOS:
            raise ValueError(f"Tipo de accion invalido: '{tipo}'")

        self.nombre = nombre
        self.descripcion = descripcion
        self.usos_max = usos_max
        self.usos_restantes = usos_max
        self.tipo = tipo
        self.valor = valor

    # ------------------------------------------------------------------
    # Consultas
    # ------------------------------------------------------------------

    def puede_usar(self) -> bool:
        """Devuelve True si quedan usos disponibles."""
        return self.usos_restantes > 0

    def barra_usos(self) -> str:
        """Retorna una barra visual con los usos restantes. Ej: [###--] 3/5"""
        llenos = self.usos_restantes
        vacios = self.usos_max - llenos
        barra = "#" * llenos + "-" * vacios
        return f"[{barra}] {self.usos_restantes}/{self.usos_max}"

    # ------------------------------------------------------------------
    # Modificaciones
    # ------------------------------------------------------------------

    def usar(self):
        """
        Descuenta un uso de la acción.
        Lanza ValueError si no hay usos restantes (no debería ocurrir si
        se valida con puede_usar() antes de llamar a este método).
        """
        if not self.puede_usar():
            raise ValueError(f"'{self.nombre}' no tiene usos disponibles.")
        self.usos_restantes -= 1

    # ------------------------------------------------------------------
    # Representación
    # ------------------------------------------------------------------

    def __str__(self) -> str:
        estado = "OK      " if self.puede_usar() else "AGOTADO "
        return f"[{estado}] {self.nombre:<18} - {self.descripcion:<38} Usos: {self.barra_usos()}"
