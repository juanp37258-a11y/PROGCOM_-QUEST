# juego.py
# Contiene la clase Juego que orquesta todo el flujo de la partida:
# bienvenida, bucle principal, combate por turnos y estadísticas finales.

import random

from personaje import Personaje
from enemigo import Enemigo, crear_enemigo_aleatorio


# Variación aleatoria aplicada al daño del héroe (±20%)
_VARIACION_DANO = 0.20

# Cada cuántos enemigos derrotados sube la dificultad
_ENEMIGOS_POR_NIVEL = 3

# Cuánto aumentan los stats por nivel de dificultad (10% por nivel)
_INCREMENTO_DIFICULTAD = 0.10


class Juego:
    """
    Controla el flujo completo de la partida.

    Responsabilidades:
    - Mostrar pantallas de bienvenida y fin de juego.
    - Crear al héroe con el nombre del jugador.
    - Generar enemigos aleatorios con dificultad progresiva.
    - Ejecutar el combate por turnos.
    - Registrar y mostrar las estadísticas finales.
    """

    def __init__(self):
        self.heroe: Personaje | None = None
        self.enemigos_derrotados: int = 0
        self.rondas_totales: int = 0
        self.dano_total_realizado: int = 0

    # ------------------------------------------------------------------
    # Punto de entrada público
    # ------------------------------------------------------------------

    def iniciar(self):
        """
        Punto de inicio de la partida.
        Muestra la bienvenida, crea al héroe y arranca el bucle principal.
        """
        self._pantalla_bienvenida()
        nombre = self._pedir_nombre()
        self.heroe = Personaje(nombre)

        print(f"\n  |> {nombre} se prepara para la batalla!")
        input("  Presiona ENTER para comenzar...")

        self._bucle_principal()

    # ------------------------------------------------------------------
    # Bucle principal
    # ------------------------------------------------------------------

    def _bucle_principal(self):
        """
        Genera enemigos y ejecuta combates hasta que el héroe muera.

        La dificultad sube un 10% cada vez que el jugador derrota
        un múltiplo de _ENEMIGOS_POR_NIVEL enemigos.
        """
        while self.heroe.esta_vivo():
            self.rondas_totales += 1

            # Calcular multiplicador de dificultad
            nivel_extra = self.enemigos_derrotados // _ENEMIGOS_POR_NIVEL
            multiplicador = 1.0 + nivel_extra * _INCREMENTO_DIFICULTAD

            if nivel_extra > 0 and self.enemigos_derrotados % _ENEMIGOS_POR_NIVEL == 0:
                print(f"\n  *** Nivel de amenaza aumentado (x{multiplicador:.1f})! ***")

            # Generar enemigo aleatorio para esta ronda
            enemigo = crear_enemigo_aleatorio(multiplicador)

            self._separador()
            print(f"  RONDA {self.rondas_totales}  |  Enemigos derrotados: {self.enemigos_derrotados}")
            print(f"\n  *** Aparece un enemigo {enemigo.tipo}: {enemigo.nombre}! ***\n")
            input("  Presiona ENTER para enfrentarlo...")

            # Ejecutar el combate
            victoria = self._combate(enemigo)

            if victoria:
                self.enemigos_derrotados += 1
                print(f"\n  *** {enemigo.nombre} fue derrotado! ***")
                if self.heroe.esta_vivo():
                    input("\n  Presiona ENTER para el siguiente combate...")
            else:
                # El héroe cayó durante el combate → salir del bucle
                break

        self._pantalla_fin()

    # ------------------------------------------------------------------
    # Combate por turnos
    # ------------------------------------------------------------------

    def _combate(self, enemigo: Enemigo) -> bool:
        """
        Ejecuta un combate completo por turnos entre el héroe y un enemigo.

        Flujo de cada turno:
          1. Mostrar estado del héroe y del enemigo.
          2. El jugador elige una acción.
          3. Se aplica el efecto de la acción.
          4. Si el enemigo sigue vivo, contraataca.
          5. Repetir hasta que uno de los dos caiga.

        Returns:
            True  si el jugador derrotó al enemigo.
            False si el héroe murió en el combate.
        """
        turno = 0

        while self.heroe.esta_vivo() and enemigo.esta_vivo():
            turno += 1
            self._separador()
            print(f"  -- Turno {turno} --")
            self._mostrar_estado(enemigo)

            # --- Turno del jugador ---
            accion = self._elegir_accion()
            print()
            self._aplicar_accion(accion, enemigo)

            # Verificar si el enemigo fue derrotado con esta acción
            if not enemigo.esta_vivo():
                break

            # --- Turno del enemigo ---
            print()
            dano_bruto = enemigo.atacar()
            dano_real = self.heroe.recibir_dano(dano_bruto)
            print(f"  {enemigo.nombre} contraataca! Inflige {dano_real} de dano.")
            print(f"  Vida de {self.heroe.nombre}: {self.heroe.barra_vida()}")

            if not self.heroe.esta_vivo():
                print(f"\n  {self.heroe.nombre} ha caido en combate...")
                return False

        return True

    # ------------------------------------------------------------------
    # Selección y aplicación de acciones
    # ------------------------------------------------------------------

    def _elegir_accion(self):
        """
        Muestra el menú de las 4 acciones y retorna la elegida.

        Validaciones:
        - Entrada no numérica.
        - Número fuera del rango 1-4.
        - Acción sin usos restantes.
        - Curación innecesaria (vida al máximo).
        """
        while True:
            print("\n  Que accion realizas?")
            for i, accion in enumerate(self.heroe.acciones, start=1):
                print(f"    {i}. {accion}")

            entrada = input("\n  Elige (1-4): ").strip()

            # Validar que sea un dígito
            if not entrada.isdigit():
                print("  [!] Entrada invalida. Escribe un numero del 1 al 4.")
                continue

            indice = int(entrada) - 1

            # Validar que esté en rango
            if indice < 0 or indice >= len(self.heroe.acciones):
                print("  [!] Opcion fuera de rango. Elige entre 1 y 4.")
                continue

            accion = self.heroe.acciones[indice]

            # Validar que tenga usos disponibles
            if not accion.puede_usar():
                print(f"  [!] '{accion.nombre}' esta agotada. Elige otra accion.")
                continue

            # Validar curación innecesaria
            if accion.tipo == "curacion" and self.heroe.vida_al_maximo():
                print("  [!] Tu vida ya esta al maximo. No puedes curar mas. Elige otra accion.")
                continue

            return accion

    def _aplicar_accion(self, accion, enemigo: Enemigo):
        """
        Ejecuta el efecto de la acción seleccionada y descuenta el uso.

        Tipos y sus efectos:
        - ataque_basico / ataque_fuerte : infligen daño al enemigo (±20% variación).
        - curacion                      : recupera HP al héroe (sin exceder el máximo).
        - defensa                       : activa el escudo táctico del héroe.
        """
        accion.usar()  # Descuenta el uso antes de aplicar el efecto

        if accion.tipo in ("ataque_basico", "ataque_fuerte"):
            # Aplicar variación aleatoria al daño base
            variacion = random.uniform(1.0 - _VARIACION_DANO, 1.0 + _VARIACION_DANO)
            dano = max(1, int(accion.valor * variacion))
            enemigo.recibir_dano(dano)
            self.dano_total_realizado += dano
            print(f"  Usas '{accion.nombre}' e infliges {dano} de dano a {enemigo.nombre}.")
            print(f"  Vida de {enemigo.nombre}: {enemigo.barra_vida()}")

        elif accion.tipo == "curacion":
            curado = self.heroe.curar(int(accion.valor))
            print(f"  Usas '{accion.nombre}' y recuperas {curado} de vida.")
            print(f"  Vida de {self.heroe.nombre}: {self.heroe.barra_vida()}")

        elif accion.tipo == "defensa":
            self.heroe.defensa_activa = True
            print(f"  Activas '{accion.nombre}'.")
            print("  El proximo ataque enemigo sera reducido un 60%.")

    # ------------------------------------------------------------------
    # Pantallas y mensajes
    # ------------------------------------------------------------------

    def _mostrar_estado(self, enemigo: Enemigo):
        """Imprime el estado actual del héroe y del enemigo lado a lado."""
        print()
        print(f"  HEROE  : {self.heroe}")
        print(f"  ENEMIGO: {enemigo}")

    def _pantalla_bienvenida(self):
        """Muestra la pantalla de título del juego."""
        self._separador()
        print("""
  +==========================================+
  |         ARENA DE HEROES  v1.0           |
  |     Un juego de combate por turnos      |
  +==========================================+

  Controlas a un heroe solitario que debe
  sobrevivir oleadas de enemigos aleatorios.

  Tienes 4 acciones con usos limitados:
    1. Ataque Basico  (15 usos)
    2. Ataque Fuerte  ( 5 usos)
    3. Curacion       ( 4 usos)
    4. Escudo Tactico ( 3 usos)

  El juego termina cuando tu vida llega a 0.
  Cuanto mas dures, mas difices seran los enemigos.
        """)

    def _pantalla_fin(self):
        """Muestra el mensaje de derrota y las estadísticas finales de la partida."""
        self._separador()
        print(f"""
  +==========================================+
  |             FIN DEL JUEGO               |
  +==========================================+

  {self.heroe.nombre} ha caido en batalla...
  Pero su leyenda permanece en la Arena.

  --------- ESTADISTICAS FINALES -----------
  Rondas jugadas          : {self.rondas_totales}
  Enemigos derrotados     : {self.enemigos_derrotados}
  Dano total realizado    : {self.dano_total_realizado}
  ------------------------------------------
        """)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _separador():
        """Imprime una línea separadora para organizar la salida en consola."""
        print("\n" + "=" * 46)

    def _pedir_nombre(self) -> str:
        """
        Solicita al jugador el nombre del héroe.
        Repite hasta recibir un nombre no vacío.
        """
        while True:
            nombre = input("\n  Ingresa el nombre de tu heroe: ").strip()
            if nombre:
                return nombre
            print("  [!] El nombre no puede estar vacio. Intentalo de nuevo.")
