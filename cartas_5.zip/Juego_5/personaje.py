# personaje.py
# Define la clase Personaje: el héroe controlado por el jugador.
# Encapsula su vida, sus 4 acciones y el estado de defensa activa.

from accion import Accion


class Personaje:
    """
    Representa al héroe controlado por el jugador.

    Contiene:
    - Estado de vida (actual y máxima).
    - Las 4 acciones de combate con usos limitados.
    - La bandera 'defensa_activa' que activa el escudo táctico.
    """

    VIDA_MAXIMA = 100  # Vida inicial y tope máximo del héroe

    def __init__(self, nombre: str):
        """
        Inicializa al héroe con vida completa y sus 4 acciones de combate.

        Args:
            nombre: Nombre del héroe ingresado por el jugador.
        """
        self.nombre = nombre
        self.vida = self.VIDA_MAXIMA
        self.defensa_activa = False  # True cuando el Escudo Táctico está en efecto

        # ---------------------------------------------------------------
        # Las 4 acciones obligatorias de la consigna
        # ---------------------------------------------------------------
        self.acciones = [
            Accion(
                nombre="Ataque Basico",
                descripcion="Golpe normal,   inflige ~15 de dano.",
                usos_max=15,          # Límite alto: acción principal de daño
                tipo="ataque_basico",
                valor=15,             # Daño base
            ),
            Accion(
                nombre="Ataque Fuerte",
                descripcion="Golpe poderoso, inflige ~35 de dano.",
                usos_max=5,           # Pocos usos: recurso valioso
                tipo="ataque_fuerte",
                valor=35,             # Daño base
            ),
            Accion(
                nombre="Curacion",
                descripcion="Recupera 30 puntos de vida.",
                usos_max=4,           # Usos limitados para balancear la partida
                tipo="curacion",
                valor=30,             # HP recuperados
            ),
            Accion(
                nombre="Escudo Tactico",
                descripcion="Reduce 60% del proximo ataque enemigo.",
                usos_max=3,           # Recurso muy limitado: usar con cabeza
                tipo="defensa",
                valor=0.60,           # Factor de reduccion de dano (60%)
            ),
        ]

    # ------------------------------------------------------------------
    # Consultas
    # ------------------------------------------------------------------

    def esta_vivo(self) -> bool:
        """Devuelve True si el héroe todavía tiene puntos de vida."""
        return self.vida > 0

    def vida_al_maximo(self) -> bool:
        """Devuelve True si la vida actual ya es igual al máximo."""
        return self.vida >= self.VIDA_MAXIMA

    def barra_vida(self) -> str:
        """
        Genera una barra visual de vida de 20 bloques.
        Ejemplo: [##########----------] 50/100
        """
        bloques = int((self.vida / self.VIDA_MAXIMA) * 20)
        vacios = 20 - bloques
        barra = "#" * bloques + "-" * vacios
        return f"[{barra}] {self.vida}/{self.VIDA_MAXIMA}"

    # ------------------------------------------------------------------
    # Modificaciones de vida
    # ------------------------------------------------------------------

    def recibir_dano(self, cantidad: int) -> int:
        """
        Aplica daño al héroe. Si el escudo está activo, reduce el daño
        según el factor de la acción 'defensa' y desactiva el escudo.

        Args:
            cantidad: Daño bruto que intenta infligir el enemigo.

        Returns:
            El daño efectivo recibido después de aplicar el escudo.
        """
        if self.defensa_activa:
            # Buscar el factor de reducción en la acción de defensa
            accion_defensa = next(
                (a for a in self.acciones if a.tipo == "defensa"), None
            )
            factor = accion_defensa.valor if accion_defensa else 0.0

            cantidad_reducida = int(cantidad * (1.0 - factor))
            self.defensa_activa = False  # El escudo se consume al recibir el impacto
            print(f"  *** Escudo activo! Dano reducido de {cantidad} a {cantidad_reducida} (-{int(factor*100)}%).")
            cantidad = cantidad_reducida

        # La vida nunca baja de 0
        self.vida = max(0, self.vida - cantidad)
        return cantidad

    def curar(self, cantidad: int) -> int:
        """
        Recupera vida al héroe sin exceder el máximo.

        Args:
            cantidad: HP que se intentan recuperar.

        Returns:
            El HP efectivamente curado (puede ser menor si se alcanza el máximo).
        """
        vida_antes = self.vida
        self.vida = min(self.VIDA_MAXIMA, self.vida + cantidad)
        return self.vida - vida_antes

    # ------------------------------------------------------------------
    # Representación
    # ------------------------------------------------------------------

    def __str__(self) -> str:
        escudo = " [ESCUDO ACTIVO]" if self.defensa_activa else ""
        return f"{self.nombre}{escudo} | Vida: {self.barra_vida()}"
