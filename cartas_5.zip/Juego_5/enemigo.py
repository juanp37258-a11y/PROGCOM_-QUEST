# enemigo.py
# Define la clase base Enemigo y sus 3 subclases (débil, neutral, fuerte).
# También expone la función fábrica crear_enemigo_aleatorio().

import random


# ------------------------------------------------------------------
# Nombres aleatorios para dar variedad y ambientación a los enemigos
# ------------------------------------------------------------------
_NOMBRES_POR_TIPO = {
    "Debil":   [
        "Goblin Ruin",
        "Rata Sombria",
        "Esqueleto Roto",
        "Slime Verde",
        "Cuervo Maldito",
    ],
    "Neutral": [
        "Orco Gris",
        "Lobo Espectral",
        "Guardia Oscuro",
        "Troll Menor",
        "Demonio Comun",
    ],
    "Fuerte":  [
        "Dragon Joven",
        "Titan Sombrio",
        "Lich Menor",
        "Bestia del Caos",
        "Senor Oscuro",
    ],
}


class Enemigo:
    """
    Clase base para todos los enemigos del juego.

    Define el comportamiento compartido:
    - Estado de vida con barra visual.
    - Método atacar() que devuelve daño aleatorio dentro de un rango.
    - Método recibir_dano() que ajusta la vida sin bajar de 0.

    Las subclases solo modifican los parámetros del constructor
    (vida, daño mínimo, daño máximo) para diferenciarse entre sí.
    """

    def __init__(
        self,
        nombre: str,
        tipo: str,
        vida: int,
        dano_min: int,
        dano_max: int,
    ):
        """
        Args:
            nombre:   Nombre del enemigo (elegido aleatoriamente).
            tipo:     Etiqueta de tipo: "Debil", "Neutral" o "Fuerte".
            vida:     Puntos de vida iniciales.
            dano_min: Daño mínimo por ataque.
            dano_max: Daño máximo por ataque.
        """
        self.nombre = nombre
        self.tipo = tipo
        self.vida_max = vida
        self.vida = vida
        self.dano_min = dano_min
        self.dano_max = dano_max

    # ------------------------------------------------------------------
    # Consultas
    # ------------------------------------------------------------------

    def esta_vivo(self) -> bool:
        """Devuelve True si el enemigo tiene puntos de vida restantes."""
        return self.vida > 0

    def barra_vida(self) -> str:
        """Genera una barra visual de vida de 20 bloques."""
        bloques = int((self.vida / self.vida_max) * 20)
        vacios = 20 - bloques
        barra = "#" * bloques + "-" * vacios
        return f"[{barra}] {self.vida}/{self.vida_max}"

    # ------------------------------------------------------------------
    # Acciones
    # ------------------------------------------------------------------

    def atacar(self) -> int:
        """
        Realiza un ataque con daño aleatorio dentro del rango del enemigo.

        Returns:
            Daño infligido (entero entre dano_min y dano_max inclusive).
        """
        return random.randint(self.dano_min, self.dano_max)

    def recibir_dano(self, cantidad: int):
        """Aplica daño al enemigo. La vida nunca baja de 0."""
        self.vida = max(0, self.vida - cantidad)

    # ------------------------------------------------------------------
    # Representación
    # ------------------------------------------------------------------

    def __str__(self) -> str:
        return f"{self.nombre} [{self.tipo}] | Vida: {self.barra_vida()}"


# ------------------------------------------------------------------
# Subclases: cada una ajusta los stats según su nivel de dificultad.
# El parámetro 'multiplicador' permite la dificultad progresiva.
# ------------------------------------------------------------------

class EnemigoDébil(Enemigo):
    """
    Enemigo fácil: poca vida y poco daño.
    Ideal para los primeros enfrentamientos.
    """

    def __init__(self, multiplicador: float = 1.0):
        vida     = int(random.randint(40, 60) * multiplicador)
        dano_min = int(8  * multiplicador)
        dano_max = int(15 * multiplicador)
        nombre   = random.choice(_NOMBRES_POR_TIPO["Debil"])
        super().__init__(nombre, "Debil", vida, dano_min, dano_max)


class EnemigoNeutral(Enemigo):
    """
    Enemigo equilibrado: stats medios.
    Representa un desafío moderado.
    """

    def __init__(self, multiplicador: float = 1.0):
        vida     = int(random.randint(70, 90) * multiplicador)
        dano_min = int(15 * multiplicador)
        dano_max = int(25 * multiplicador)
        nombre   = random.choice(_NOMBRES_POR_TIPO["Neutral"])
        super().__init__(nombre, "Neutral", vida, dano_min, dano_max)


class EnemigoFuerte(Enemigo):
    """
    Enemigo peligroso: mucha vida y alto daño.
    Requiere usar bien las acciones especiales para sobrevivir.
    """

    def __init__(self, multiplicador: float = 1.0):
        vida     = int(random.randint(100, 130) * multiplicador)
        dano_min = int(25 * multiplicador)
        dano_max = int(40 * multiplicador)
        nombre   = random.choice(_NOMBRES_POR_TIPO["Fuerte"])
        super().__init__(nombre, "Fuerte", vida, dano_min, dano_max)


# ------------------------------------------------------------------
# Fábrica de enemigos aleatorios
# ------------------------------------------------------------------

def crear_enemigo_aleatorio(multiplicador: float = 1.0) -> Enemigo:
    """
    Crea y devuelve un enemigo al azar entre los 3 tipos disponibles.

    Args:
        multiplicador: Factor de dificultad. Valores > 1.0 producen
                       enemigos con más vida y más daño (progresión).

    Returns:
        Una instancia de EnemigoDébil, EnemigoNeutral o EnemigoFuerte.
    """
    ClaseEnemigo = random.choice([EnemigoDébil, EnemigoNeutral, EnemigoFuerte])
    return ClaseEnemigo(multiplicador)
