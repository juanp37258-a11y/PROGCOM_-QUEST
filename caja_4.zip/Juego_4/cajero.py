"""
cajero.py
=========
Define la clase Cajero, que orquesta el flujo completo de una venta:
desde recibir los productos hasta imprimir la factura y registrarla.
"""

from typing import List, Optional

from catalogo import Catalogo
from detalle_factura import DetalleFactura
from exportador import Exportador
from factura import Factura
from qr_modulo import GeneradorQR


class Cajero:
    """
    Orquesta el flujo de una sesión de venta en el supermercado.

    Responsabilidades:
        - Guiar al usuario para seleccionar productos y cantidades
        - Construir la factura con los detalles de la compra
        - Coordinar con Exportador para guardar la venta
        - Coordinar con GeneradorQR para mostrar el QR (opcional)

    Atributos:
        catalogo         (Catalogo)       : Fuente de productos disponibles
        exportador       (Exportador)     : Responsable de guardar archivos
        generador_qr     (GeneradorQR)    : Módulo opcional de QR
        facturas_del_dia (List[Factura])  : Registro de ventas de la sesión actual
    """

    def __init__(self, catalogo: Catalogo):
        self.catalogo          = catalogo
        self.exportador        = Exportador()
        self.generador_qr      = GeneradorQR()
        self.facturas_del_dia: List[Factura] = []

    # ── Flujo principal de venta ─────────────────────────────────────────────

    def iniciar_venta(self) -> Optional[Factura]:
        """
        Inicia una nueva sesión de venta.
        Guía al usuario para agregar productos y cerrar la compra.
        Retorna la Factura generada, o None si se canceló.
        """
        detalles: List[DetalleFactura] = []

        print("\n" + "=" * 60)
        print(f"{'NUEVA VENTA':^60}")
        print("=" * 60)
        print("  Ingresa el CÓDIGO o NOMBRE del producto.")
        print("  Escribe 'VER' para mostrar el catálogo.")
        print("  Escribe 'FIN' para terminar la selección.")
        print("-" * 60)

        while True:
            entrada = input("\n  Producto (código / nombre / VER / FIN): ").strip()

            # ── Entrada vacía ───────────────────────────────────────────────
            if not entrada:
                print("  [!] Entrada vacía. Intenta de nuevo.")
                continue

            # ── Comandos especiales ─────────────────────────────────────────
            if entrada.upper() == "VER":
                self.catalogo.mostrar_catalogo()
                continue

            if entrada.upper() == "FIN":
                if not detalles:
                    respuesta = input(
                        "  [!] No has agregado ningún producto. ¿Salir? (s/n): "
                    ).strip().lower()
                    if respuesta == "s":
                        print("  Venta cancelada.")
                        return None
                    continue
                break  # Salir del ciclo para cerrar la venta

            # ── Buscar producto ─────────────────────────────────────────────
            producto = self._buscar_producto(entrada)
            if producto is None:
                continue

            # ── Pedir cantidad ──────────────────────────────────────────────
            cantidad = self._pedir_cantidad(producto.nombre)
            if cantidad is None:
                continue

            # ── Agregar o acumular en la lista ──────────────────────────────
            self._agregar_detalle(detalles, producto, cantidad)

        # ── Cerrar la venta ─────────────────────────────────────────────────
        return self._cerrar_venta(detalles)

    # ── Búsqueda de producto ─────────────────────────────────────────────────

    def _buscar_producto(self, entrada: str):
        """
        Busca un producto por código o por nombre.
        Si hay varios resultados por nombre, pide al usuario elegir uno.
        Retorna el Producto encontrado o None.
        """
        # Intentar por código primero
        producto = self.catalogo.buscar_por_codigo(entrada)
        if producto:
            return producto

        # Si no encontró por código, buscar por nombre
        resultados = self.catalogo.buscar_por_nombre(entrada)

        if len(resultados) == 1:
            return resultados[0]

        if len(resultados) > 1:
            return self._elegir_de_lista(resultados)

        print(f"  [!] No se encontró ningún producto con '{entrada}'.")
        print("  Verifica el código en el catálogo (opción 'VER').")
        return None

    def _elegir_de_lista(self, productos):
        """Muestra múltiples coincidencias y pide al usuario elegir una."""
        print("\n  Se encontraron varios productos:")
        for i, p in enumerate(productos, start=1):
            print(f"    {i}. [{p.codigo}] {p.nombre}  ${p.precio:.2f}")

        while True:
            opcion = input("  Elige el número (0 para cancelar): ").strip()
            if opcion == "0":
                return None
            try:
                indice = int(opcion) - 1
                if 0 <= indice < len(productos):
                    return productos[indice]
                print(f"  [!] Número fuera de rango. Elige entre 1 y {len(productos)}.")
            except ValueError:
                print("  [!] Debes ingresar un número entero.")

    # ── Pedir cantidad ───────────────────────────────────────────────────────

    def _pedir_cantidad(self, nombre_producto: str) -> Optional[int]:
        """
        Solicita y valida la cantidad de un producto.
        Retorna el entero positivo ingresado, o None si se cancela.
        """
        while True:
            entrada = input(f"  Cantidad de '{nombre_producto}' (0 para cancelar): ").strip()
            if entrada == "0":
                print("  [!] Producto no agregado.")
                return None
            try:
                cantidad = int(entrada)
                if cantidad < 0:
                    print("  [!] La cantidad no puede ser negativa.")
                elif cantidad == 0:
                    print("  [!] La cantidad debe ser mayor a 0.")
                else:
                    return cantidad
            except ValueError:
                print("  [!] Ingresa un número entero válido.")

    # ── Agregar o actualizar detalle ─────────────────────────────────────────

    def _agregar_detalle(self, detalles: List[DetalleFactura], producto, cantidad: int):
        """
        Agrega un nuevo detalle a la lista o suma la cantidad si ya existe.
        """
        # Buscar si el producto ya está en la lista
        existente = next(
            (d for d in detalles if d.producto.codigo == producto.codigo), None
        )

        if existente:
            existente.actualizar_cantidad(existente.cantidad + cantidad)
            print(
                f"  [+] Actualizado: {producto.nombre} "
                f"→ {existente.cantidad} uds  (subtotal: ${existente.subtotal:.2f})"
            )
        else:
            nuevo_detalle = DetalleFactura(producto, cantidad)
            detalles.append(nuevo_detalle)
            print(
                f"  [+] Agregado: {producto.nombre} "
                f"x{cantidad}  =  ${nuevo_detalle.subtotal:.2f}"
            )

    # ── Cerrar venta ─────────────────────────────────────────────────────────

    def _cerrar_venta(self, detalles: List[DetalleFactura]) -> Optional[Factura]:
        """
        Muestra el resumen, pide confirmación, genera la factura y la guarda.
        """
        self._mostrar_resumen(detalles)

        confirmar = input("  ¿Confirmar compra? (s/n): ").strip().lower()
        if confirmar != "s":
            print("  Venta cancelada. No se generó factura.")
            return None

        # Crear y mostrar la factura
        factura = Factura(detalles)
        factura.imprimir()

        # Guardar en archivo
        self.exportador.guardar_venta(factura)
        self.facturas_del_dia.append(factura)

        # Ofrecer QR de forma opcional
        qr = input("  ¿Mostrar código QR de la factura? (s/n): ").strip().lower()
        if qr == "s":
            self.generador_qr.generar_qr_factura(factura)

        return factura

    # ── Resumen de compra ────────────────────────────────────────────────────

    def _mostrar_resumen(self, detalles: List[DetalleFactura]):
        """Imprime en consola el resumen antes de confirmar la compra."""
        ancho = 60
        print("\n" + "-" * ancho)
        print(f"{'RESUMEN DE COMPRA':^{ancho}}")
        print("-" * ancho)
        print(f"  {'PRODUCTO':<28} {'CANT':>4} {'P.UNIT':>11}  {'SUBTOTAL':>10}")
        print("-" * ancho)
        for d in detalles:
            print(f"  {d}")
        print("-" * ancho)
        total = sum(d.subtotal for d in detalles)
        print(f"  {'TOTAL':>{ancho - 16}}  ${total:>10.2f}")
        print("-" * ancho)

    # ── Estadísticas del día ─────────────────────────────────────────────────

    def exportar_resumen_dia(self):
        """Delega al exportador para generar el CSV con las ventas del día."""
        if not self.facturas_del_dia:
            print("\n  [!] No se registraron ventas en esta sesión.")
            return
        self.exportador.exportar_resumen_csv(self.facturas_del_dia)

    def mostrar_estadisticas_dia(self):
        """Muestra en pantalla un resumen rápido de las ventas de la sesión."""
        if not self.facturas_del_dia:
            print("\n  [!] No se registraron ventas en esta sesión.")
            return

        total_dia   = sum(f.total for f in self.facturas_del_dia)
        num_ventas  = len(self.facturas_del_dia)

        print("\n" + "=" * 50)
        print(f"{'ESTADÍSTICAS DE LA SESIÓN':^50}")
        print("=" * 50)
        print(f"  Número de ventas realizadas : {num_ventas}")
        print(f"  Total recaudado             : ${total_dia:.2f}")
        print(f"  Promedio por venta          : ${total_dia / num_ventas:.2f}")
        print("=" * 50)
