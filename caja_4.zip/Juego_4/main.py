"""
main.py
=======
Punto de entrada del sistema de cajero del supermercado.
Muestra el menú principal y coordina las acciones del usuario.

Ejecutar:
    python main.py
"""

import os
import sys

from catalogo import Catalogo
from cajero import Cajero


# ── Utilidades de consola ────────────────────────────────────────────────────

def limpiar_pantalla():
    """Limpia la pantalla en Windows (cls) y en Linux/Mac (clear)."""
    os.system("cls" if os.name == "nt" else "clear")


def pausar():
    """Espera a que el usuario presione Enter."""
    input("\n  Presiona Enter para continuar...")


# ── Menús ────────────────────────────────────────────────────────────────────

def mostrar_bienvenida():
    """Pantalla de bienvenida al iniciar el programa."""
    print("=" * 60)
    print(f"{'SUPERMERCADO EL BUEN PRECIO':^60}")
    print(f"{'Sistema de Cajero Automático':^60}")
    print(f"{'v1.0 - Desarrollado en Python con POO':^60}")
    print("=" * 60)


def mostrar_menu() -> str:
    """Imprime el menú principal y retorna la opción ingresada."""
    print("\n" + "=" * 60)
    print(f"{'MENÚ PRINCIPAL':^60}")
    print("=" * 60)
    print("  1. Ver catálogo de productos")
    print("  2. Iniciar nueva venta")
    print("  3. Ver estadísticas de la sesión")
    print("  4. Exportar resumen del día (CSV)")
    print("  5. Salir del sistema")
    print("=" * 60)
    return input("  Selecciona una opción (1-5): ").strip()


# ── Programa principal ───────────────────────────────────────────────────────

def main():
    limpiar_pantalla()
    mostrar_bienvenida()

    # ── Inicialización ───────────────────────────────────────────────────────
    print("\n  Cargando sistema...")
    catalogo = Catalogo(ruta_archivo="datos/productos.json")

    if not catalogo.productos:
        print("\n  [ERROR CRÍTICO] No se pudieron cargar los productos.")
        print("  Verifica que el archivo 'datos/productos.json' exista y sea válido.")
        sys.exit(1)

    cajero = Cajero(catalogo)
    print("  Sistema listo.\n")
    pausar()

    # ── Bucle principal ──────────────────────────────────────────────────────
    while True:
        limpiar_pantalla()
        mostrar_bienvenida()
        opcion = mostrar_menu()

        # 1. Ver catálogo
        if opcion == "1":
            limpiar_pantalla()
            catalogo.mostrar_catalogo()
            pausar()

        # 2. Nueva venta
        elif opcion == "2":
            limpiar_pantalla()
            catalogo.mostrar_catalogo()
            cajero.iniciar_venta()
            pausar()

        # 3. Estadísticas de la sesión
        elif opcion == "3":
            limpiar_pantalla()
            cajero.mostrar_estadisticas_dia()
            pausar()

        # 4. Exportar resumen CSV
        elif opcion == "4":
            limpiar_pantalla()
            cajero.exportar_resumen_dia()
            pausar()

        # 5. Salir
        elif opcion == "5":
            limpiar_pantalla()
            print("\n" + "=" * 60)
            print(f"{'Cerrando el sistema...':^60}")
            print(f"{'¡Hasta luego!':^60}")
            print("=" * 60 + "\n")
            break

        else:
            print("  [!] Opción no válida. Elige un número del 1 al 5.")
            pausar()


if __name__ == "__main__":
    main()
