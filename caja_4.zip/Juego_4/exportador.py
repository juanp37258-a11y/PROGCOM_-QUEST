"""
exportador.py
=============
Define la clase Exportador, responsable de guardar las ventas del día
en archivos de texto y exportar resúmenes en formato CSV.
"""

import os
from datetime import datetime
from typing import List


class Exportador:
    """
    Gestiona la persistencia de las ventas en archivos.

    Responsabilidades:
        - Guardar cada factura en un archivo .txt del día
        - Exportar un resumen en CSV con todas las ventas del día

    Atributos:
        carpeta_ventas (str): Ruta de la carpeta donde se guardan los archivos
    """

    def __init__(self, carpeta_ventas: str = "ventas"):
        self.carpeta_ventas = carpeta_ventas
        # Crea la carpeta si no existe
        os.makedirs(self.carpeta_ventas, exist_ok=True)

    # ── Guardar factura individual ───────────────────────────────────────────

    def guardar_venta(self, factura) -> bool:
        """
        Guarda el texto de la factura en el archivo de ventas del día.
        El archivo se llama 'ventas_AAAA-MM-DD.txt'.
        Retorna True si se guardó correctamente, False en caso de error.
        """
        fecha_hoy = datetime.now().strftime("%Y-%m-%d")
        nombre_archivo = os.path.join(
            self.carpeta_ventas, f"ventas_{fecha_hoy}.txt"
        )

        try:
            # Modo 'a' (append) para agregar sin borrar ventas anteriores del día
            with open(nombre_archivo, "a", encoding="utf-8") as archivo:
                archivo.write(factura.to_texto())
                archivo.write("\n")
            print(f"  [OK] Venta registrada en '{nombre_archivo}'.")
            return True

        except IOError as e:
            print(f"  [ERROR] No se pudo guardar la venta en archivo: {e}")
            return False

    # ── Exportar resumen CSV ─────────────────────────────────────────────────

    def exportar_resumen_csv(self, facturas: List) -> bool:
        """
        Exporta un resumen de todas las facturas del día en formato CSV.
        El archivo se llama 'resumen_AAAA-MM-DD.csv'.
        Retorna True si se exportó correctamente, False en caso de error.
        """
        if not facturas:
            print("  [!] No hay ventas para exportar.")
            return False

        fecha_hoy = datetime.now().strftime("%Y-%m-%d")
        nombre_archivo = os.path.join(
            self.carpeta_ventas, f"resumen_{fecha_hoy}.csv"
        )

        try:
            with open(nombre_archivo, "w", encoding="utf-8") as archivo:
                # Encabezado del CSV
                archivo.write("factura_numero,fecha,hora,cantidad_productos,total\n")

                total_dia = 0.0
                for factura in facturas:
                    total_dia += factura.total
                    archivo.write(
                        f"{factura.numero:04d},"
                        f"{factura.fecha_hora.strftime('%d/%m/%Y')},"
                        f"{factura.fecha_hora.strftime('%H:%M:%S')},"
                        f"{len(factura.detalles)},"
                        f"{factura.total:.2f}\n"
                    )

                # Fila de totales al final
                archivo.write(f"\nTOTAL DEL DÍA,,,, {total_dia:.2f}\n")

            print(f"  [OK] Resumen exportado en '{nombre_archivo}'.")
            print(f"  [OK] Total vendido en el día: ${total_dia:.2f}")
            return True

        except IOError as e:
            print(f"  [ERROR] No se pudo exportar el resumen: {e}")
            return False
