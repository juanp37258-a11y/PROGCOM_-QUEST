"""
catalogo.py
===========
Define la clase Catalogo, que carga los productos desde un archivo JSON
y permite buscarlos por código o por nombre.
"""

import json
import os
from typing import Dict, List, Optional

from producto import Producto


class Catalogo:
    """
    Gestiona la colección de productos disponibles en el supermercado.

    Responsabilidades:
        - Cargar productos desde un archivo JSON
        - Proveer búsqueda por código y por nombre
        - Mostrar el catálogo en pantalla de forma organizada

    Atributos:
        ruta_archivo (str)             : Ruta al archivo JSON de productos
        productos    (Dict[str, Producto]): Diccionario código -> Producto
    """

    def __init__(self, ruta_archivo: str = "datos/productos.json"):
        self.ruta_archivo = ruta_archivo
        self.productos: Dict[str, Producto] = {}
        self._cargar_productos()

    # ── Carga de datos ──────────────────────────────────────────────────────

    def _cargar_productos(self):
        """Carga los productos desde el archivo JSON."""
        if not os.path.exists(self.ruta_archivo):
            print(f"\n  [ADVERTENCIA] No se encontró '{self.ruta_archivo}'.")
            print("  El catálogo quedará vacío. Crea el archivo con los productos.\n")
            return

        try:
            with open(self.ruta_archivo, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)

            # Validar que sea una lista
            if not isinstance(datos, list):
                print("  [ERROR] El archivo JSON debe contener una lista de productos.")
                return

            for item in datos:
                # Validar que cada producto tenga los campos requeridos
                campos_requeridos = {"codigo", "nombre", "precio", "categoria", "stock"}
                if not campos_requeridos.issubset(item.keys()):
                    print(f"  [ADVERTENCIA] Producto omitido por campos faltantes: {item}")
                    continue

                producto = Producto(
                    codigo=str(item["codigo"]),
                    nombre=str(item["nombre"]),
                    precio=float(item["precio"]),
                    categoria=str(item["categoria"]),
                    stock=int(item["stock"])
                )
                self.productos[producto.codigo] = producto

            print(f"  [OK] {len(self.productos)} productos cargados desde '{self.ruta_archivo}'.")

        except json.JSONDecodeError as e:
            print(f"  [ERROR] El archivo JSON tiene formato incorrecto: {e}")
        except (KeyError, ValueError, TypeError) as e:
            print(f"  [ERROR] Datos inválidos en el archivo de productos: {e}")

    # ── Búsquedas ───────────────────────────────────────────────────────────

    def buscar_por_codigo(self, codigo: str) -> Optional[Producto]:
        """Busca un producto por su código exacto. Retorna None si no existe."""
        return self.productos.get(codigo.strip().upper(), None)

    def buscar_por_nombre(self, nombre: str) -> List[Producto]:
        """Busca productos cuyo nombre contenga el texto ingresado (sin importar mayúsculas)."""
        nombre = nombre.strip().lower()
        return [p for p in self.productos.values() if nombre in p.nombre.lower()]

    # ── Visualización ───────────────────────────────────────────────────────

    def mostrar_catalogo(self):
        """Imprime el catálogo completo en pantalla, agrupado por categoría."""
        if not self.productos:
            print("\n  [!] El catálogo está vacío.")
            return

        ancho = 65
        print("\n" + "=" * ancho)
        print(f"{'CATÁLOGO DE PRODUCTOS':^{ancho}}")
        print("=" * ancho)
        print(f"  {'CÓD':<8} {'NOMBRE':<28} {'PRECIO':>10}   {'STOCK':>6}")
        print("-" * ancho)

        # Agrupar por categoría
        categorias: Dict[str, List[Producto]] = {}
        for p in self.productos.values():
            categorias.setdefault(p.categoria, []).append(p)

        for categoria in sorted(categorias):
            print(f"\n  ── {categoria.upper()} ──")
            for p in sorted(categorias[categoria], key=lambda x: x.nombre):
                print(f"  {p.codigo:<8} {p.nombre:<28} ${p.precio:>9.2f}   {p.stock:>5} uds")

        print("\n" + "=" * ancho)
