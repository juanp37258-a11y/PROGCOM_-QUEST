"""
detalle_factura.py
==================
Define la clase DetalleFactura, que representa una línea dentro de la factura:
un producto con su cantidad y el subtotal calculado.
"""

from producto import Producto


class DetalleFactura:
    """
    Representa una línea de la factura (producto + cantidad + subtotal).

    Atributos:
        producto  (Producto) : El producto comprado
        cantidad  (int)      : Cuántas unidades se compraron
        subtotal  (float)    : precio * cantidad (se calcula automáticamente)
    """

    def __init__(self, producto: Producto, cantidad: int):
        if not isinstance(producto, Producto):
            raise TypeError("El parámetro 'producto' debe ser una instancia de Producto.")
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser un número entero positivo.")

        self.producto = producto
        self.cantidad = cantidad
        self.subtotal = self._calcular_subtotal()

    def _calcular_subtotal(self) -> float:
        """Calcula el subtotal de esta línea."""
        return self.producto.precio * self.cantidad

    def actualizar_cantidad(self, nueva_cantidad: int):
        """Actualiza la cantidad y recalcula el subtotal."""
        if nueva_cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor a 0.")
        self.cantidad = nueva_cantidad
        self.subtotal = self._calcular_subtotal()

    def __str__(self) -> str:
        """Formato de una línea de factura."""
        return (f"{self.producto.nombre:<28} "
                f"{self.cantidad:>3} x ${self.producto.precio:>9.2f}"
                f"  = ${self.subtotal:>10.2f}")
