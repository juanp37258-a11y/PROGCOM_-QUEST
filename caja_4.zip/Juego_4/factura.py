"""
factura.py
==========
Define la clase Factura, que agrupa los detalles de una compra,
calcula el total y puede imprimirse en pantalla o exportarse como texto.
"""

from datetime import datetime
from typing import List
from detalle_factura import DetalleFactura


class Factura:
    """
    Representa una factura de venta completa.

    Atributos de clase (constantes de la tienda):
        NOMBRE_TIENDA : Nombre del negocio
        DIRECCION     : Dirección física
        NIT           : Número de identificación tributaria
        _contador     : Numerador automático de facturas (se incrementa con cada instancia)

    Atributos de instancia:
        numero      (int)                 : Número único de esta factura
        fecha_hora  (datetime)            : Fecha y hora de la venta
        detalles    (List[DetalleFactura]): Líneas de productos comprados
        total       (float)               : Suma de todos los subtotales
    """

    # ── Datos de la tienda ──────────────────────────────────────────────────
    NOMBRE_TIENDA = "SUPERMERCADO EL BUEN PRECIO"
    DIRECCION     = "Calle 123 #45-67, Ciudad"
    NIT           = "NIT: 900.123.456-7"
    TELEFONO      = "Tel: (601) 555-0199"

    # Numerador automático compartido entre todas las facturas
    _contador: int = 1

    def __init__(self, detalles: List[DetalleFactura]):
        if not detalles:
            raise ValueError("Una factura debe tener al menos un detalle.")

        self.numero    = Factura._contador
        Factura._contador += 1
        self.fecha_hora = datetime.now()
        self.detalles   = detalles
        self.total      = sum(d.subtotal for d in detalles)

    # ── Métodos de presentación ─────────────────────────────────────────────

    def imprimir(self):
        """Imprime la factura en consola con formato de tiquete."""
        print(self._construir_texto(ancho=60))

    def to_texto(self) -> str:
        """Retorna la factura como cadena de texto (para guardar en archivo)."""
        return self._construir_texto(ancho=60)

    def _construir_texto(self, ancho: int = 60) -> str:
        """
        Construye el texto de la factura.
        Se usa tanto para imprimir en pantalla como para exportar a archivo.
        """
        sep_doble  = "=" * ancho
        sep_simple = "-" * ancho
        lineas = []

        # ── Encabezado ──────────────────────────────────────────────────────
        lineas.append(f"\n{sep_doble}")
        lineas.append(f"{self.NOMBRE_TIENDA:^{ancho}}")
        lineas.append(f"{self.DIRECCION:^{ancho}}")
        lineas.append(f"{self.NIT:^{ancho}}")
        lineas.append(f"{self.TELEFONO:^{ancho}}")
        lineas.append(sep_doble)

        # ── Datos de la factura ─────────────────────────────────────────────
        lineas.append(f"  Factura N°: {self.numero:04d}")
        lineas.append(f"  Fecha     : {self.fecha_hora.strftime('%d/%m/%Y')}")
        lineas.append(f"  Hora      : {self.fecha_hora.strftime('%H:%M:%S')}")
        lineas.append(sep_simple)

        # ── Encabezado de columnas ──────────────────────────────────────────
        lineas.append(
            f"  {'PRODUCTO':<28} {'CANT':>4} {'P.UNIT':>11}  {'SUBTOTAL':>10}"
        )
        lineas.append(sep_simple)

        # ── Líneas de productos ─────────────────────────────────────────────
        for detalle in self.detalles:
            lineas.append(f"  {detalle}")

        # ── Total ───────────────────────────────────────────────────────────
        lineas.append(sep_simple)
        lineas.append(f"  {'TOTAL A PAGAR':>{ancho - 16}}  ${self.total:>10.2f}")
        lineas.append(sep_doble)
        lineas.append(f"{'¡Gracias por su compra!':^{ancho}}")
        lineas.append(f"{'Conserve su factura':^{ancho}}")
        lineas.append(f"{sep_doble}\n")

        return "\n".join(lineas)
