"""
qr_modulo.py
============
Módulo preparado para la generación de códigos QR en facturas.

Estado actual: SIMULACIÓN
    El módulo funciona completamente en modo simulado, mostrando en consola
    los datos que irían codificados en el QR.

Para activar QR real:
    1. Instala la librería:  pip install qrcode[pil]
    2. Cambia MODO_SIMULACION = False en la clase GeneradorQR.
    3. Los QR se guardarán como imágenes PNG en la carpeta 'qr/'.
"""

import os


class GeneradorQR:
    """
    Genera (o simula) un código QR con la información de una factura.

    Atributos de clase:
        MODO_SIMULACION (bool): Si True, muestra el QR en consola.
                                Si False, genera una imagen PNG real.
    """

    MODO_SIMULACION: bool = True  # ← Cambiar a False para QR real

    def __init__(self, carpeta_qr: str = "qr"):
        self.carpeta_qr = carpeta_qr

    # ── Método principal ─────────────────────────────────────────────────────

    def generar_qr_factura(self, factura):
        """
        Genera o simula el código QR de una factura.
        Recibe un objeto Factura y extrae sus datos relevantes.
        """
        datos = self._construir_datos(factura)

        if self.MODO_SIMULACION:
            self._mostrar_simulacion(datos, factura.numero)
        else:
            self._generar_imagen_real(datos, factura.numero)

    # ── Construcción de datos ────────────────────────────────────────────────

    def _construir_datos(self, factura) -> str:
        """
        Construye la cadena de texto que irá codificada en el QR.
        Formato: campo:valor separados por '|'
        """
        partes = [
            f"FACTURA:{factura.numero:04d}",
            f"FECHA:{factura.fecha_hora.strftime('%d/%m/%Y')}",
            f"HORA:{factura.fecha_hora.strftime('%H:%M:%S')}",
            f"TOTAL:{factura.total:.2f}",
            f"TIENDA:{factura.NOMBRE_TIENDA}",
        ]

        # Agregar cada producto como: COD xCANT
        for detalle in factura.detalles:
            partes.append(f"{detalle.producto.codigo}x{detalle.cantidad}")

        return "|".join(partes)

    # ── Modo simulación ──────────────────────────────────────────────────────

    def _mostrar_simulacion(self, datos: str, numero_factura: int):
        """Muestra en consola una representación visual del QR simulado."""
        print("\n  ┌─────────────────────────────────────────┐")
        print("  │           CÓDIGO QR - SIMULACIÓN        │")
        print("  │  ┌───────────────────────────────────┐  │")
        print("  │  │  ██▀▀▀██  ▀  ██▀▀▀██  ▄▄▄▄▄▄▄▄▄  │  │")
        print("  │  │  ██▄▄▄██  █  ██▄▄▄██  █  █████  │  │")
        print("  │  │  ▀▀▀▀▀▀▀  ▄  ▀▀▀▀▀▀▀  ▄▄▄█████  │  │")
        print("  │  │   (representación visual simulada) │  │")
        print("  │  └───────────────────────────────────┘  │")
        print(f"  │  Factura N°: {numero_factura:04d}                      │")
        print(f"  │  Datos codificados ({len(datos)} caracteres)        │")
        print("  │                                         │")
        print("  │  Para QR real: pip install qrcode[pil] │")
        print("  │  Luego cambia MODO_SIMULACION = False   │")
        print("  └─────────────────────────────────────────┘\n")

    # ── Modo QR real ─────────────────────────────────────────────────────────

    def _generar_imagen_real(self, datos: str, numero_factura: int):
        """
        Genera una imagen PNG con el código QR real.
        Requiere: pip install qrcode[pil]
        """
        try:
            import qrcode  # type: ignore  # noqa: F401

            os.makedirs(self.carpeta_qr, exist_ok=True)
            nombre_archivo = os.path.join(
                self.carpeta_qr, f"qr_factura_{numero_factura:04d}.png"
            )

            img = qrcode.make(datos)
            img.save(nombre_archivo)
            print(f"  [QR] Código QR guardado en '{nombre_archivo}'.")

        except ImportError:
            print("  [QR] Librería 'qrcode' no encontrada.")
            print("       Instálala con:  pip install qrcode[pil]")
            print("       Mostrando simulación en su lugar...\n")
            self._mostrar_simulacion(datos, numero_factura)
