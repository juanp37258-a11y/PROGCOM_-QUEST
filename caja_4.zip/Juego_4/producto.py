"""
producto.py
===========
Define la clase Producto, que representa un artículo disponible en el supermercado.
"""


class Producto:
    """
    Representa un producto del supermercado.

    Atributos:
        codigo    (str)   : Identificador único del producto (ej. 'F001')
        nombre    (str)   : Nombre descriptivo del producto
        precio    (float) : Precio unitario
        categoria (str)   : Categoría del producto (ej. 'Lácteos')
        stock     (int)   : Cantidad disponible en inventario
    """

    def __init__(self, codigo: str, nombre: str, precio: float,
                 categoria: str, stock: int):
        self.codigo = codigo.upper()
        self.nombre = nombre
        self.precio = float(precio)
        self.categoria = categoria
        self.stock = int(stock)

    def __str__(self) -> str:
        """Representación legible para mostrar en catálogo."""
        return (f"[{self.codigo:<6}] {self.nombre:<28} "
                f"${self.precio:>9.2f}   Stock: {self.stock}")

    def to_dict(self) -> dict:
        """Convierte el producto a diccionario (útil para guardar en JSON)."""
        return {
            "codigo": self.codigo,
            "nombre": self.nombre,
            "precio": self.precio,
            "categoria": self.categoria,
            "stock": self.stock
        }
